import logging
import telebot
from telebot import types
import config
import db
import cl

bot = telebot.TeleBot(config.telegram_token, threaded=False)
logging.basicConfig(filename="bot.log",
                    format='%(asctime)s: %(levelname)s - %(module)s - %(funcName)s - %(lineno)d - %(message)s',
                    level=logging.INFO)
logging.info("BOT STARTED")


def create_main_menu_keyboard(message):
    """
    Функция добавления интерфейса для пользователя, немного различается в зависимости от роли пользователя
    :return:
    """
    rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item_change_password = types.KeyboardButton('Изменить пароль')
    item_change_login = types.KeyboardButton('Изменить логин')
    item_back = types.KeyboardButton('Назад')
    rmk.add(item_change_login, item_change_password)
    if db.User.get_who_is(message):
        item_change_take_give_work = types.KeyboardButton('Взять заказ')
    else:
        item_change_take_give_work = types.KeyboardButton('Создать заказ')
        item_my_project = types.KeyboardButton('Мои проекты')
        rmk.add(item_my_project)
    rmk.add(item_change_take_give_work, item_back)
    return rmk


def _set_username(message):
    """
    Функция для проверки, что у пользователя установлен username
    1 - Если username есть, то отправляем пользователя в главное меню
    2 - Если username не стоит, то сообщаем об этом пользователю и просим установить, не перенаправляя в главное меню
    :param message:
    :return:
    """
    if message.from_user.username is not None:
        logging.info(f"User {message.from_user.username} has username, hence he is starting registration")
        start(message)
    else:
        logging.info(f"User {message.from_user.username} doesn't have username")
        keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
        keyboard.row('Я указал username')

        bot.send_message(message.chat.id, "К сожалению мы не видим ваш username, попробуйте чуть позже",
                         reply_markup=keyboard)
        bot.register_next_step_handler(message, callback=_set_username)


@bot.message_handler(commands=['start'])
def start(message):
    """
    Фунция привествует пользователя и дает выбор 'РЕГИСТРАЦИЯ' и 'АВТОРИЗАЦИЯ'
    :param message:
    :return:
    """
    user = db.User.exists(message.chat.id)
    if user:
        rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
        rmk.add(types.KeyboardButton('АВТОРИЗАЦИЯ'), types.KeyboardButton('РЕГИСТРАЦИЯ'))
        logging.info(f"User {user.username} tried to restart bot")

        bot.send_message(message.chat.id,
                         ' С возвращением :)!',
                         reply_markup=rmk)
        bot.register_next_step_handler(message, user_answer)
    else:
        if message.from_user.username is None:
            logging.info(f"New user {user.username} tried to register without username")
            keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
            keyboard.row('Я указал username')

            bot.send_message(message.chat.id,
                             "К сожалению у вас не указан username, поэтому мы не можем с вами работать, так как не "
                             "хотим")
            bot.send_message(message.chat.id,
                             "Укажите username в своем телеграмм аккаунте, чтобы продолжить работу с ботом",
                             reply_markup=keyboard)
            bot.register_next_step_handler(message, callback=_set_username)
        else:
            db.User.create_safe(message.from_user.id, message.chat.id, message.from_user.username, 1, 1)
            keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
            keyboard.row("Я разрешил добавлять меня в группы")
            bot.send_message(message.chat.id,
                             'Привет, чтобы пользоваться нашим ботом, тебе нужно разрешить добавлять себя в чаты в '
                             'настройках телеграмма. ',
                             reply_markup=keyboard)
            bot.register_next_step_handler(message, user_answer)


def user_answer(message):
    """
    Обработка ответов пользователя при регистрации и авторизации, на эту функцию ссылаются другие фукнкции при ответе
    Если написать что-то то она ничего не сделает и запутит сама себя,
    пока пользователь не нажмет на кнопку ничего не произойдет. Для каждого вида ответов выполняются соответсвующие
    логически связанные функции
    :param message:
    :return:
    """
    if message.text == 'АВТОРИЗАЦИЯ':
        bot.send_message(message.chat.id, 'Пройдите авторизацию', reply_markup=types.ReplyKeyboardRemove())
        bot.send_message(message.chat.id, 'Введите ваш логин.')
        bot.register_next_step_handler(message, autorization_login)
    elif message.text == 'РЕГИСТРАЦИЯ':
        bot.send_message(message.chat.id, 'Пройдите регистрацию', reply_markup=types.ReplyKeyboardRemove())
        bot.send_message(message.chat.id, 'Введите ваш логин.')
        bot.register_next_step_handler(message, registration_login)
    elif message.text == 'Я разрешил добавлять меня в группы':
        rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
        rmk.add(types.KeyboardButton('АВТОРИЗАЦИЯ'), types.KeyboardButton('РЕГИСТРАЦИЯ'))
        bot.send_message(message.chat.id, 'Благодарю, теперь можете пройти регистрацию и авторизоваться в нашем боте',
                         reply_markup=rmk)
        bot.register_next_step_handler(message, user_answer)
    elif message.text == 'Исполнитель':
        completer(message)
    elif message.text == 'Заказчик':
        customer(message)
    elif message.text == 'Назад':
        who_is(message)
    elif message.text == 'Изменить пароль':
        bot.send_message(message.chat.id, 'Введите ваш новый пароль.')
        bot.register_next_step_handler(message, password_changing)
    elif message.text == 'Изменить логин':
        bot.send_message(message.chat.id, 'Введите ваш новый логин.')
        bot.register_next_step_handler(message, login_changing)
    elif message.text == 'Создать заказ':
        create_project(message)
    elif message.text == 'Взять заказ':
        i = -5
        product_data = list_product()
        inline_mrk = create_inline_keyboard(i)
        bot.send_message(message.chat.id, f"""<strong>{product_data[0]['proj_name']}</strong>
                <i>{product_data[0]['text']}</i>
                    """, parse_mode='HTML', reply_markup=inline_mrk)
        bot.register_next_step_handler(message, user_answer)
    elif message.text == 'Мои проекты':
        get_project(message)
    # elif message.text == 'START' or 'start' or 'Start':
    #     start(message)
    elif message.text != '/start':
        bot.register_next_step_handler(message, user_answer)
        logging.info(f' {message.from_user.username} не нажал на кнопку, а написал что-то')


def password_changing(message):
    """
    Фунуция меняет пароль пользователя и отправляет ему пользовательский интерфейс(create_main_menu_keyboard)
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} поменял пароль')
    db.User.set_password(message)
    bot.send_message(message.chat.id, f'Ваш новый пароль {db.User.get_password(message)}',
                     reply_markup=create_main_menu_keyboard(message))
    bot.register_next_step_handler(message, user_answer)


def login_changing(message):
    """
    Фунуция меняет логин пользователя и отправляет ему пользовательский интерфейс(create_main_menu_keyboard)
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} поменял логин')
    db.User.set_login(message)
    bot.send_message(message.chat.id, f'Ваш новый логин {db.User.get_login(message)}',
                     reply_markup=create_main_menu_keyboard(message))
    bot.register_next_step_handler(message, user_answer)


def autorization_login(message):
    """
    Функция авторизации. Запрашивает логин, если неверный все начинается сначало. Если верный логин, то вызыввается
    функция autorization_password
    :param message:
    :return:
    """

    if message.text == db.User.get_login(message):
        logging.info(f' {message.from_user.username} ввел верный логин')
        bot.send_message(message.chat.id, 'Введите ваш пароль.')
        bot.register_next_step_handler(message, autorization_password)
    else:
        bot.send_message(message.chat.id, 'Ваш логин неверен, попробуйте снова.')
        logging.info(f' {message.from_user.username} ввел неверный логин')
        start(message)


def autorization_password(message):
    """
    Функция заканчивает авторизацию пользователя и дальше вызывает функцию выбора who_is
    :param message:
    :return:
    """

    if message.text == db.User.get_password(message):
        bot.send_message(message.chat.id, 'Все совпало.')
        logging.info(f' {message.from_user.username} успешно авторизировался')
        who_is(message)
    else:
        bot.send_message(message.chat.id, 'Ваш пароль неверен, попробуйте снова.')
        logging.info(f' {message.from_user.username} ввел неверный пароль')
        start(message)


def registration_login(message):
    """
    Функция регистрации пользователя, записывает значение логина и просит ввести пароль
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} попросили ввести его новый логин')
    db.User.set_login(message)
    bot.send_message(message.chat.id, 'Введите пароль.')
    bot.register_next_step_handler(message, registration_password)


def registration_password(message):
    """
    Функция регистрации пользователя, записывает значение пароля и отправляет его в начало для авторизации
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} попросили ввести его новый пароль')
    db.User.set_password(message)
    bot.send_message(message.chat.id,
                     f'Ваши логин и пароль: {db.User.get_login(message)} {db.User.get_password(message)}. Поздравляю '
                     f'с успешной регистрацией, теперь можете авторизоваться',
                     )
    start(message)


def who_is(message):
    """
    Функция дает пользователю выбор, кем он хочет быть сегодня
    :param message:
    :return:
    """
    logging.info(f'У {message.from_user.username} cпросили о том, кем является пользователь')
    rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
    rmk.add(types.KeyboardButton('Исполнитель'), types.KeyboardButton('Заказчик'))
    bot.send_message(message.chat.id, 'Вы являетесь исполнителем или заказчиком?', reply_markup=rmk)
    bot.register_next_step_handler(message, user_answer)


def completer(message):
    """
    Выяснилось, что юзер является исполнителем, поэтому выполняются функции ниже.
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} стал испонителем')
    db.User.set_who_is(message)
    bot.send_message(message.chat.id, 'Теперь вы исполнитель', reply_markup=create_main_menu_keyboard(message))
    bot.register_next_step_handler(message, user_answer)


def customer(message):
    """
    Выяснилось, что юзер является заказчиком, поэтому выполняются функции ниже.
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} стал заказчиком')
    db.User.set_who_is(message)
    bot.send_message(message.chat.id, 'Теперь вы заказчик', reply_markup=create_main_menu_keyboard(message))
    bot.register_next_step_handler(message, user_answer)


def create_project(message):
    """
    Главная функция по созданию проекта, которая по церочке ведет к остальным функциям. Тут создается пустой проект в
    бд, а также берется его уникальный id и сохраняется в параметре Id
    """
    logging.info(f'У {message.from_user.username} попросили ввести название проекта')
    aa = db.Project.create_safe(message.from_user.id)
    Id = aa.id
    bot.send_message(message.chat.id, 'Введите название проекта.', reply_markup=types.ReplyKeyboardRemove())
    bot.register_next_step_handler(message, callback=project_name, Id=Id)


def project_name(message, Id):
    """
    Сохраняет в бд название проекта и отправляет пользователя в след шаг, то есть на сохрание описания проекта
    :param message:
    :param Id: уникальное значение каждого сохраненного проекта
    """
    logging.info(f'У {message.from_user.username} попросили ввести описание проекта')
    db.Project.set_project_name(Id, message)
    bot.send_message(message.chat.id, 'Спасибо, введите описание проекта.')
    bot.register_next_step_handler(message, callback=project_text, Id=Id)


def project_text(message, Id):
    """
    Сохраняет в бд описание проекта и отправляет пользователя в след шаг, то есть на сохрание файла
    :param message:
    :param Id: уникальное значение каждого сохраненного проекта
    """
    logging.info(f'У {message.from_user.username} попросили файл к проекту')
    db.Project.set_text(Id, message)
    rmk = types.ReplyKeyboardMarkup(resize_keyboard=True)
    rmk.add(types.KeyboardButton('Далее'))
    bot.send_message(message.chat.id, 'Спасибо, теперь можете прикрепить файл(фото не отправлять) к вашему проекту. '
                                      'Просто отправьте его '
                                      'мне :). Если хотите пропустить этот шаг, то нажмите на кнопку далее.',
                     reply_markup=rmk)
    bot.register_next_step_handler(message, callback=safe_document, Id=Id)


def list_product():
    """
        Функия берет все наши проекты и сохраняет их в список product_data.
        :return: возвращает наш список
        """
    products = db.Project.get_document()
    product_data = []
    for product in products:
        product_data.append({
            'id': product.id,
            'proj_name': product.project_name,
            'text': product.text,
            'document': product.document,
        })
    return product_data


def send_doc(message, i):
    """
    Если есть документ, то отправляем позьвателю, если нет, то пишем ему, что файлов никаких нет
    :param message:
    :param i: счеткик, необходимый для работы со списком
    :return:
    """
    product_data = list_product()
    if product_data[i]['document'] == 'None':
        bot.send_message(message.chat.id, "Пользователь не прикреплял никаких документов")
    else:
        logging.info(f' {message.from_user.username} получил файл проекта')
        doc = open(product_data[i]['document'], 'rb')
        bot.send_document(message.chat.id, doc)
        doc.close()


def create_inline_keyboard(i):
    """
    Создает кнопки под сообщением, в callback_data также отправляем i
    :param i: счеткик, необходимый для работы со списком
    :return:
    """
    inline_mrk = types.InlineKeyboardMarkup()
    item_next = types.InlineKeyboardButton(text='Далее', callback_data='next ' + str(i))
    item_prev = types.InlineKeyboardButton(text='Назад', callback_data='prev ' + str(i))
    item_comment = types.InlineKeyboardButton(text='Оставить отклик', callback_data='comment ' + str(i))
    inline_mrk.add(item_prev, item_next)
    inline_mrk.add(item_comment)
    item_take_doc = types.InlineKeyboardButton(text='Получить файл', callback_data='take_doc ' + str(i))
    inline_mrk.add(item_take_doc)
    return inline_mrk


def take_project(message, i):
    """
    1. Функия берет список проектов и клавиатуру для сообщений с помощью функций list_product и create_inline_keyboard
    соответственно.
    2. Если счетчик будет больше кол-ва наших проектов, то мы его обнуляем.
    3. Выдает пользователю след проект
    :param message:
    :param i:счеткик, необходимый для работы со списком
    """
    product_data = list_product()
    count = len(product_data)
    if i >= count:
        i = 0
    inline_mrk = create_inline_keyboard(i)
    if i >= 0:
        logging.info(f' {message.from_user.username} выбирает проект, который хочет взять')
        bot.edit_message_text(chat_id=message.chat.id, text=f"""<strong>{product_data[i]['proj_name']}</strong>
<i>{product_data[i]['text']}</i>
                    """, parse_mode='HTML', reply_markup=inline_mrk, message_id=message.message_id)
    # bot.register_next_step_handler(message=message, callback=user_answer)


@bot.callback_query_handler(func=lambda call: True)
def answer(call):
    """
    Функция отвечает за реагирование на нажатие кнопок inline
    :param call:
    :return:
    """
    string = call.data
    text, a = string.split(" ")
    id = 100
    id_comment = 100
    if "_" in a:
        id, i = a.split("_")
        id = int(id)
        if "=" in i:
            i, id_comment = i.split("=")
            id_comment = int(id_comment)
        i = int(i)
    else:
        i = int(a)
    if i < 0:
        i = 0
    if text == 'next':
        take_project(i=i + 1, message=call.message)
    elif text == 'prev':
        take_project(i=i - 1, message=call.message)
    elif text == 'comment':
        bot.send_message(call.message.chat.id, "Оставьте свой отклик.")
        bot.register_next_step_handler(message=call.message, callback=comment, i=i)
    elif text == 'take_doc':
        send_doc(i=i, message=call.message)
    elif text == 'delete':
        delete_project(message=call.message, id=i)
    elif text == 'check_comment':
        print_comment(message=call.message, i=i)
    elif text == 'next_comment':
        check_comment(message=call.message, id=id, i=i + 1)
    elif text == 'prev_comment':
        check_comment(message=call.message, id=id, i=i - 1)
    elif text == 'performer':
        create_chat(message=call.message, id_comment=id_comment)


def print_comment(message, i):
    """
    Функция выдает заказчику отклик на его проект.
    :param message:
    :param i:
    :return:
    """
    product_data = list_comments(i)
    if not product_data:
        logging.info(f'Пользователю {message.from_user.username} сообщили, что откликов нет')
        bot.send_message(message.chat.id, "На этом проекте пока 0 откликов")
    else:
        logging.info(f' {message.from_user.username} посмотрел отклик номер {i}')
        inline_mrk = comment_inline(i, 0, product_data[0]['id_comment'])
        bot.send_message(chat_id=message.chat.id, text=f"""<strong>{product_data[0]['comment']}</strong>
                                """, parse_mode='HTML', reply_markup=inline_mrk)

    bot.register_next_step_handler(message=message, callback=user_answer)


def comment(message, i):
    """
    Пользователь оставляет свой отклик. Отклик можно оставить только один раз.
    :param message:
    :param i:
    :return:
    """
    product = list_product()
    username = db.User.get_username(message.chat.id)
    comm = db.Comment.exists(username)
    proj = db.Comment.exists_proj_id(product[i]['id'])
    if comm and proj:
        logging.info(f'Пользователю {message.from_user.username} сообщили, что нельзя оставлять более одного отклика')
        bot.send_message(message.chat.id, "Вы уже оставили отклик на этот проект.")
    else:
        logging.info(f'Поользователь {message.from_user.username} оставил отклик на проект')
        db.Comment.create_safe(comment=message.text, username=username, proj_id=product[i]['id'])
        bot.send_message(message.chat.id, """Спасибо за отклик!😊
Если Вас выберут исполнителем, то мы обязательно сообщим Вам.
        """)
    # user_answer(message)


def my_product(message):
    """
    Функция возвращает список проектов, которые создал заказчик
    :param message:
    :return:
    """
    logging.info(f'У {message.from_user.username} автоматически создался список проектов')
    products = db.Project.get_document()
    product_data = []
    for product in products:
        if product.user_id == message.from_user.id:
            product_data.append({
                'id': product.id,
                'proj_name': product.project_name,
                'text': product.text,
                'document': product.document
            })
    return product_data


def project_inline(id):
    """
    Функция создает inline клавиатуру для работы с проектами заказчика
    :param id: уникальный id проекта в бд
    :return:
    """
    inline_mrk = types.InlineKeyboardMarkup()
    item_delete = types.InlineKeyboardButton(text='Удалить', callback_data='delete ' + str(id))
    inline_mrk.add(item_delete)
    item_check_comment = types.InlineKeyboardButton(text='Посмотреть отклики', callback_data='check_comment ' + str(id))
    inline_mrk.add(item_check_comment)
    return inline_mrk


def get_project(message):
    """
    Функция отправляет все проекты заказчика
    :param message:
    :return:
    """
    logging.info(f' {message.from_user.username} просмторел свой список проектов')
    product_data = my_product(message)
    count = len(product_data)
    for i in range(count):
        bot.send_message(chat_id=message.chat.id, text=f"""<strong>{product_data[i]['proj_name']}</strong>
<i>{product_data[i]['text']}</i>
                            """, parse_mode='HTML', reply_markup=project_inline(product_data[i]['id']))


def delete_project(message, id):
    """
    Функция удаляет проект и все связанные с ним отклики из бд
    :param message:
    :param id: уникальный параметр проекта в бд
    :return:
    """
    logging.info(f' {message.from_user.username} удалил проект под номером {id}')
    db.Project.delete_project(id)
    bot.edit_message_text(chat_id=message.chat.id, text="Проект удален", message_id=message.message_id)
    bot.register_next_step_handler(message, user_answer)


def comment_inline(id, i, id_comment):
    """
    Функция создает inline клавиатуру для взаимодействия с отклками, оставленными под проектом
    :param id_comment: уникальный параметр отклика
    :param id: уникальный параметр проекта в бд
    :param i: счетчик, необходимый для пролистывания откликов
    :return:
    """
    inline_mrk = types.InlineKeyboardMarkup()
    item_next = types.InlineKeyboardButton(text='Далее', callback_data='next_comment ' + str(id) + '_' + str(i)
                                                                       + '=' + str(id_comment))
    item_prev = types.InlineKeyboardButton(text='Назад', callback_data='prev_comment ' + str(id) + '_' + str(i)
                                                                       + '=' + str(id_comment))
    item_comment = types.InlineKeyboardButton(text='Выбрать исполнителем', callback_data='performer ' + str(id) + '_'
                                                                                         + str(i) + '=' + str(
        id_comment))
    inline_mrk.add(item_prev, item_next)
    inline_mrk.add(item_comment)
    return inline_mrk


def list_comments(id):
    """
    Создает список с откликами на проект
    :param id: уникальный параметр проекта в бд
    :return:
    """
    comments = db.Project.get_comment(int(id))
    product_data = []
    for product in comments:
        product_data.append({
            'id_comment': product.id,
            'comment': product.comment,
            'username': product.username
        })
    return product_data


def check_comment(message, id, i):
    """
    Функция предназначена для пролистывания откликов на проект
    :param message:
    :param id: уникальный параметр проекта в бд
    :param i: счеткич необходимый для пролистывания
    :return:
    """
    product_data = list_comments(id)
    count = len(product_data)
    print(count)
    if i >= count:
        i = 0
    inline_mrk = comment_inline(id, i, product_data[i]['id_comment'])
    if i >= 0 and count != 1:
        bot.edit_message_text(chat_id=message.chat.id, text=f"""<strong>{product_data[i]['comment']}</strong>
                        """, parse_mode='HTML', reply_markup=inline_mrk, message_id=message.message_id)


@bot.message_handler(content_types=['photo'])
def safe_photo(message):  # TODO:исправить доку и добавить недостающие логи
    logging.info(f' {message.from_user.username} сохранил фото')
    raw = message.photo[0].file_id
    file_info = bot.get_file(raw)
    downloaded_file = bot.download_file(file_info.file_path)
    src = file_info.file_path
    with open(src, 'wb') as new_file:
        new_file.write(downloaded_file)


def safe_document(message, Id):
    """
    Сохраняет документ, который прислал пользователь в папке documents, если нечего сохранять, то пользователь может
    пропустить этот шаг
    :param message:
    :param Id: уникальное значение каждого сохраненного проекта
    """
    if message.text == 'Далее':
        logging.info(f' {message.from_user.username} создал проект под номером {Id} без файла')
        bot.send_message(message.chat.id, 'На этом все, Ваш проект сохранен и теперь ждите предложения,Свои проекты '
                                          'можете увидеть в глваном меню',
                         reply_markup=create_main_menu_keyboard(message))
        bot.register_next_step_handler(message, user_answer)
    else:
        logging.info(f' {message.from_user.username} создал проект под номером {Id} с файлом')
        raw = message.document.file_id
        file_info = bot.get_file(raw)
        downloaded_file = bot.download_file(file_info.file_path)
        src = 'documents/' + message.document.file_name
        with open(src, 'wb') as new_file:
            new_file.write(downloaded_file)
            db.Project.set_document(Id, src)
        bot.send_message(message.chat.id, 'На этом все, Ваш проект сохранен и теперь ждите предложения,Свои проекты '
                                          'можете увидеть в глваном меню',
                         reply_markup=create_main_menu_keyboard(message))
        bot.register_next_step_handler(message, user_answer)


def create_chat(message, id_comment):
    """
    Функция создает чат
    :param message:
    :param id_comment:
    :return:
    """
    chat_name = 'test test'
    username = db.Comment.get_username(id_comment)
    user = db.User.exists(message.chat.id)
    clients = cl.clients()
    client = clients.pop(0)
    chat_users = [user.username, username]
    cl.create_chat(client=client, chat_name=chat_name, users=chat_users)
    bot.send_message(message.chat.id, "Все, создалась беседа с исполнителем")
    bot.register_next_step_handler(message, user_answer)


bot.enable_save_next_step_handlers(delay=0)
bot.load_next_step_handlers()
if __name__ == "__main__":
    print("Starting bot")
    bot.polling(none_stop=True)
