from peewee import PostgresqlDatabase, Model, CharField, IntegerField, BigIntegerField

import config

db = PostgresqlDatabase(config.database_name, host=config.database_host, port=config.database_port,
                        user=config.database_user,
                        password=config.database_password)


class Base(Model):
    class Meta:
        database = db


class User(Base):
    chat_id = IntegerField(primary_key=True)
    user_id = BigIntegerField(unique=True)
    username = CharField()
    login = CharField()
    password = CharField()
    who_is = IntegerField(default=2)  # 0 - заказчик 1 - исполнитель

    @staticmethod
    def set_login(message):
        user = User.get(User.chat_id == message.chat.id)
        login = message.text
        user.login = login
        user.save()

    @staticmethod
    def set_password(message):
        user = User.get(User.chat_id == message.chat.id)
        password = message.text
        user.password = password
        user.save()

    @staticmethod
    def set_who_is(message):
        user = User.get(User.chat_id == message.chat.id)
        if message.text == "Заказчик":
            who_is = 0
        else:
            who_is = 1
        user.who_is = who_is
        user.save()

    @staticmethod
    def exists(chat_id):
        """
        Проверяет, есть ли такой пользователь уже в бд
        :param chat_id:
        :return:
        """
        user = User.select().where(User.chat_id == chat_id)
        if len(user) != 0:
            return user[0]
        else:
            return False

    @staticmethod
    def get_login(message):
        return User.get(User.user_id == message.from_user.id).login

    @staticmethod
    def get_password(message):
        return User.get(User.user_id == message.from_user.id).password

    @staticmethod
    def get_who_is(message):
        return User.get(User.user_id == message.from_user.id).who_is

    @staticmethod
    def get_username(chat_id):
        return User.get(User.chat_id == chat_id).username

    @staticmethod
    def create_safe(user_id, chat_id, username, login, password):
        """
        Создает нового пользователя в бд
        """
        if not User.exists(chat_id):
            return User.create(user_id=user_id, chat_id=chat_id, username=username, login=login, password=password)


User.create_table()


class Portfolio(Base):
    user_id = BigIntegerField(unique=True)
    type_of = IntegerField()  # 0 - дизайн 1 - мобилка 2 - сайт 3 - бот
    photo = CharField()
    text = CharField()

    @staticmethod
    def create_safe(user_id, type_of, photo, text):
        """
        Создает нового пользователя в бд
        """
        return User.create(user_id=user_id, type_of=type_of, photo=photo, text=text)


Portfolio.create_table()


class Project(Base):
    user_id = BigIntegerField()
    type_of = IntegerField(default=4)  # 0 - дизайн 1 - мобилка 2 - сайт 3 - бот
    photo = CharField(default='None')
    document = CharField(default='None')
    text = CharField(default='None')
    project_name = CharField(default='None')

    @staticmethod
    def get_document():
        return Project.select()

    @staticmethod
    def set_document(Id, document):
        category = Project.get(Project.id == Id)
        category.document = document
        category.save()

    @staticmethod
    def set_project_name(Id, message):
        project_name = message.text
        category = Project.get(Project.id == Id)
        category.project_name = project_name
        category.save()

    @staticmethod
    def set_text(Id, message):
        text = message.text
        category = Project.get(Project.id == Id)
        category.text = text
        category.save()

    @staticmethod
    def delete_project(Id):
        project = Project.select().where(Project.id == Id)
        comment = Comment.select().where(Comment.proj_id == Id)
        if len(project) != 0:
            project[0].delete_instance()
        if len(comment) != 0:
            comment[0].delete_instance()

    @staticmethod
    def get_comment(Id):
        comment = Comment.select().where(Comment.proj_id == Id)
        return comment

    @staticmethod
    def create_safe(user_id):
        return Project.create(user_id=user_id)


Project.create_table()


class Comment(Base):
    username = CharField()
    proj_id = IntegerField()
    comment = CharField()

    @staticmethod
    def get_username(Id):
        return Comment.get(Comment.id == Id).username

    @staticmethod
    def exists(username):
        """
        Проверяет, есть ли такой пользователь уже в бд
        :param username:
        :return:
        """
        user = Comment.select().where(Comment.username == username)
        if len(user) != 0:
            return user[0]
        else:
            return False

    @staticmethod
    def exists_proj_id(proj_id):
        """
        Проверяет, есть ли такой пользователь уже в бд
        :param proj_id:
        :return:
        """
        user = Comment.select().where(Comment.proj_id == proj_id)
        if len(user) != 0:
            return user[0]
        else:
            return False

    @staticmethod
    def create_safe(comment, proj_id, username):
        if not Comment.exists_proj_id(proj_id):
            return Comment.create(comment=comment, proj_id=proj_id, username=username)


Comment.create_table()
