telegram_token = "1703698224:AAF9efTVmyHR8--rohZmIFP0VOj9jviB6iA"  # это мой токен от @mipt_pybot, Гугл
# расскажет как получить его у BotFather
usernames = ["@arolg"]
api_id = "4196236"
api_hash = "b8cdaeddf7c3a673a8ae330d16980bd6"
# Database
# database_name = "dbname"
# database_host = "database-1.c1np7pbgncmh.us-east-2.rds.amazonaws.com"
# database_port = 5432
# database_user = "postgres"
# database_password = "d50e46ff7fe02fd3100f856557a4f486b2f52ac75f55bc197080969b710e9bfd"

# Database
database_name = "postgres"
database_host = "localhost"
database_port = 5432
database_user = "postgres"
database_password = "18679"