from pyrogram import Client
import config


def clients():
    """
    Функция логинится к клиенту и возвращает его
    :return:
    """
    clients = []
    for username in config.usernames:
        print("USERNAME:", username)
        client = Client(username, config.api_id, config.api_hash)
        client.start()
        clients.append(client)
        print("READY")
    return clients


def create_chat(client, chat_name, users):
    """
    Создает чат с заказчиком, исполнителем и модератором
    :param client:
    :param chat_name:
    :param users:
    :return:
    """
    pinned_message = "Привет, можете тут общаться начет проекта, если Вам понадобится решение модератора по " \
                     "конфликтным ситуациям, то просто пинганите меня. Удачи "
    chat = client.create_supergroup(chat_name, pinned_message)
    client.add_chat_members(chat.id, users)
    message = client.send_message(chat.id, pinned_message)
    client.pin_chat_message(chat.id, message.message_id)
    return chat.id
